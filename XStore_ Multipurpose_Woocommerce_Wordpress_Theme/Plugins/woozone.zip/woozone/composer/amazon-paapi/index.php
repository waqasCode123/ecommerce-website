<?php die('silence is gold!');
//"rossjcooper/paapiphpsdk": ">=1.0.0"