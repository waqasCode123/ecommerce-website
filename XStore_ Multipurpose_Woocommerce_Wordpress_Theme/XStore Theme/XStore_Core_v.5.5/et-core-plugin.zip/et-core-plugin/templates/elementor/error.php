<div class="error">

	<p><?php echo esc_html( $error_message ); ?></p>

</div>
