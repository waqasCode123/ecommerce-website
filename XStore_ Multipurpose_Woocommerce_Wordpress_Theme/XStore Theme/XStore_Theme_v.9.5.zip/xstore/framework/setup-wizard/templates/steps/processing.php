<?php if ( ! defined('ETHEME_FW')) exit('No direct script access allowed');
/**
 * Template "processing" - step for ET_Setup_Wizard.
 * @package ET_Setup_Wizard
 * @since 9.5.0
 * @version 1.0.0
 */

?>

<div class="wizard-step wizard-precessing">
	<div class="wizard-step-content">
		<h1>processing theme</h1>
		<p>processing-textsts</p>
	</div>
	<div class="wizard-step-controllers">
		<a href="<?php echo ET_Setup_Wizard::get_controls_url('register'); ?>" class="wizard-controllers-button">next</a>
	</div>
</div>