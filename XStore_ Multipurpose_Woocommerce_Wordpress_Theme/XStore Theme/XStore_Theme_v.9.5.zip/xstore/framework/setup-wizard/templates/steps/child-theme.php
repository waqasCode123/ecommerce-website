<?php if ( ! defined('ETHEME_FW')) exit('No direct script access allowed');
/**
 * Template "Child theme" - step for ET_Setup_Wizard.
 * @package ET_Setup_Wizard
 * @since 9.5.0
 * @version 1.0.0
 */

?>

<div class="wizard-step container-mini wizard-child-theme">
	<div class="wizard-step-content">
		<?php
		$theme = get_option('xstore_has_child') ? wp_get_theme(get_option('xstore_has_child') )->Name : 'Xstore child';
		$template = get_template();
		?>
        <div class="wizard-step-heading text-center">
            <h2><?php esc_html_e('Setup XStore child theme (optional)', 'xstore'); ?></h2>
            <p>
                <?php esc_html_e('A child theme lets you update XSTORE safely and keep your changes. We strongly recommend using it!', 'xstore') ?>
                <?php ET_Setup_Wizard::get_tooltip(esc_html__('A child theme lets you safely update XStore without losing your custom changes. Ideal for developers or anyone planning to modify code, styles, or templates.', 'xstore'), true); ?>
            </p>
        </div>
        <form id="et_create-child_theme-form" class="text-center" action="" method="POST" style="max-width: 320px; margin: 0 auto;">
            <div class="child-theme-input" style="margin-bottom: 20px;">
                <label for="theme_name">
                    <?php esc_html_e('Child theme name', 'xstore'); ?>
                </label>
                <input class="text-center" type="text" id="theme_name" name="theme_name" value="<?php echo esc_attr($theme); ?>" placeholder="<?php echo esc_attr($theme); ?>">
            </div>
            <div class="child-theme-input" style="margin-bottom: 20px;">
                <label for="theme_template">
                    <?php esc_html_e('Parent Theme Template', 'xstore'); ?>
                </label>
                <span class="mtips mtips-lg text-left helping">
                    <input class="text-center" type="text" id="theme_template" name="theme_template" value="<?php echo esc_attr($template); ?>" placeholder="<?php echo esc_attr($template); ?>" readonly>
                    <span class="mt-mes">
                        Parent theme is defined by the ‘Template’ in child theme’s style.css; to change it, rename its folder in /wp-content/themes/ and restart setup from the first step to apply changes.
                    </span>
                </span>
            </div>
        </form>
        <p class="et-success et-message hidden">
            <?php esc_html_e('Child Theme ', 'xstore'); ?>
            <strong class="new-theme-title"></strong>
            <?php esc_html_e('created and activated successfully! Folder is located in:', 'xstore'); ?>
            <strong class="new-theme-path"></strong>
        </p>
        <p class="et-error et-message hidden">
            <?php esc_html_e('Can not create or activate new child theme. Please contact our support.', 'xstore'); ?>
        </p>
	</div>
	<div class="wizard-step-controllers">
        <a href="" class="setup-button wizard-controllers-button create-child-theme">Install child theme</a>
		<a href="<?php echo ET_Setup_Wizard::get_controls_url('demos'); ?>" class="setup-button-link wizard-controllers-button">Skip this step</a>
        <input type="hidden" name="nonce_etheme-create_child_theme" value="<?php echo wp_create_nonce( 'etheme-create_child_theme' ); ?>">
	</div>
</div>
