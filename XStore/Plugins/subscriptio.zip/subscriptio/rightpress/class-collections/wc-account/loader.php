<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

// Load class collection files

require_once 'rightpress-wc-account.class.php';
