<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WooCommerce Product Admin
 *
 * @class RP_SUB_WC_Product_Object_Admin
 * @package Subscriptio
 * @author RightPress
 */
abstract class RP_SUB_WC_Product_Object_Admin extends RightPress_WC_Product_Object_Admin
{

    /**
     * Constructor
     *
     * @access public
     * @return void
     */
    public function __construct()
    {

        // Call parent constructor
        parent::__construct();
    }





}
