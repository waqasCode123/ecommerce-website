<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

// Load dependencies
require_once 'abstract/rp-sub-wc-custom-order-object-data-store.class.php';

/**
 * Subscription Data Store
 *
 * @class RP_SUB_Subscription_Data_Store
 * @package Subscriptio
 * @author RightPress
 */
class RP_SUB_Subscription_Data_Store extends RP_SUB_WC_Custom_Order_Object_Data_Store
{





}
