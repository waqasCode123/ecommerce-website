<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WordPress Post Type Data Store
 *
 * @class RP_SUB_WP_Post_Object_Data_Store
 * @package Subscriptio
 * @author RightPress
 */

abstract class RP_SUB_WP_Post_Object_Data_Store extends RightPress_WP_Custom_Post_Object_Data_Store
{




}
