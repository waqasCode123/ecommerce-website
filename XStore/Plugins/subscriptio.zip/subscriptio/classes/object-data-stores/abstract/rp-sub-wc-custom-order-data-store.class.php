<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WooCommerce Custom Order Data Store
 *
 * @class RP_SUB_WC_Custom_Order_Data_Store
 * @package Subscriptio
 * @author RightPress
 */
abstract class RP_SUB_WC_Custom_Order_Data_Store extends RightPress_WC_Custom_Order_Data_Store
{





}
