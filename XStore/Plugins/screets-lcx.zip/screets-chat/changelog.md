# Changelog

We always try to keep our products up-to-date and secure. 
If you find any bug, please report us: https://screets.com/contact

    [+] New, [*]: Change, [!]: Fix

---

## 3.7.6

August 21, 2024

[+] Support PHP 8.3
[+] Tested with WordPress 6.6
[*] Remove dark mode to fix compatibility issue with some themes and Firefox

## 3.7.5

February 27, 2024

[+] Support PHP 8.2
[*] Deprecate update checker
[*] Deprecate WP user authentication and WooCommerce integration
[!] Skip 3.7.4 update for WordPress users

## 3.7.3

January 31, 2024

[+] Add dark mode support for chat widget
[!] Improve mobile responsiveness

## 3.7.2

December 5, 2023

[!] Tested with 6.4.1 (fix compatibility issue)
[*] Requires minimum WordPress 6.0

## 3.7.1

4 November, 2023

  [+] WordPress 6.4 support

## 3.7.0

15 October, 2023

  [+] Agents can now send up to 1750 characters, increased from 1k.
  [*] Tested with WordPress 6.3.2

## 3.6.2

17 August, 2023

  [*] Tested with WordPress 6.3

## 3.6.1

12 June, 2023

  [*] Tested with WordPress 6.2.2
  [*] WordPress version updated

## 3.6.0

27 March, 2023

  [+] WordPress 6.2 support
  [*] Improved Korean and Spanish translations (thanks to REX from Korea and Albert from Spain)
  [!] Fixed response time issue on widget

## 3.5.0

25 January, 2023

  [+] PHP 8.x support

## 3.4.5

12 October, 2022

  [+] WordPress 6.1 support

## 3.4.4

5 August, 2022

  [!] Fixed wrong folder name (WordPress)

## 3.4.3

4 August, 2022

  [*] Tested with WordPres 6.0.1

## 3.4.2

17 June, 2022

  [+] Translate collector card fields directly from WordPress
  [!] Fix showing response time info in collector card

## 3.4.1

16 June, 2022

  [*] WordPress 6.0 support

## 3.4.1

21 March, 2022

  [+] Add collector card
  [*] Only ask audio permission to Safari users (when new conversation is created)
  [*] Mark as read automatically when you close conversation
  [*] Don't greet user on chat widget header when user's name is actually an email
  [!] Fix showing re-activated conversations on inbox

## 3.3.3

12 January, 2022
  
    [+] Add visitor details into notification emails sent through offline form (i.e. name, phone, email, browser and OS info)

## 3.3.2

04 January, 2022
  
  [!] WordPress: Fix repeated plugin update checks

## 3.3.1

17 December, 2021
  
  [+] WordPress: Check new plugin updates automatically
  [*] WordPress: Use "wp_remote_post" for sending WooCommerce data to Chat app
  [!] WordPress: Updated chat console dashboard to the latest version
  [!] Fixed going online/offline status updates on chat widget


## 3.3.0

December 13, 2021

  [+] Display exceptions (Show up chat widget on specific pages)
  [+] WordPress: Automatically recognize logged-in WordPress users
  [+] WooCommerce: Create a chat in background including order details when the customer place an order, so your operators can see in your chat console and reply
  [+] JavaScript API: Identity Verification (a.k.a Custom User Authentication)
  [+] Greet returning visitors on chat widget header (i.e. Hello John)
  [*] Whitelabel: screets Chat name can be removable from the chat widget
  [*] Whitelabel: Notification emails (sent to your clients) now use Application Name and logo (instead of screets brand)
  [*] No need to authorize domains starting with "www". It's automatically recognized

## 3.2.0

October 20, 2021

  [+] New chat starter icon
  [+] New appearance option: "Hide chat widget when all operators are offline"
  [+] Auto-detect language and translate strings of the chat widget (i.e. Turkish, French, Spanish, Italian, etc.)
  [+] Set your custom titles for chat widget
  [+] Set your custom Google Font for chat widget
  [+] Show "green badge" on chat starter button when at least one operator is online
  [+] Sound notifications to chat console
  [+] URLs are clickable in chat messages (including e-mails)
  [+] Recognize RTL messages on chat
  [*] Better design for in-app message (in other words, chat button title)
  [*] Show only online operators on chat widget on online mode (when at least one operator is online)
  [*] Increase maximum height of chat popup from 580px to 720px
  [*] Improve stability of embedded chat console in WordPress
  [!] Fix chat popup header sizing issue on first load
  [!] Fix unable to disable "hide me on chat widget" option

## 3.1.1

October 5, 2021
  
  [+] New option for operators to hide themselves from operators list on chat widget: "Settings > General > Hide me on chat widget"
  [*] Improve licensing (including updating quotas)
  [*] Re-arrange positioning green badge of online operator pictures (avatars)

## 3.1.0

September 28, 2021

  [+] New theme for widget (Settings > Widget)
  [+] Dark mode support for chat widget
  [+] Sound notifications for visitors
  [+] WPML support #WordPress
  [*] Fresh and intuitive design for form fields
  [*] Refactoring chat widget design and core. Smooth page transitions and improved stability
  [*] Show "Chats" button on welcome page only if there is a chat
  [*] Remembering returned visitors for the next 48 hours starting and resets counting every visit (previously 24 hours)
  [!] Improved compatibility to PHP 7 servers #WordPress

## 3.0.2

September 14, 2021

  [*] Improve stability of escaping translations

## 3.0.1

September 14, 2021

[!] Fixed translation issue


## 3.0.0

August 30, 2021

The first release! It's dedicated to "Atatürk" who is founder of the modern Turkiye.

  [+] First release 😀
  [+] All new (design & core)
  [+] Blazing-fast! Huge performance improvements
  [+] No Firebase dependency
  [+] Works all around the world including China 🇨🇳
  [+] Works in all web platforms (including HTML and PHP)
  [+] No server installation required
  [+] Image and File uploads
  [+] Departments for everyone